"""2026-10-20 KW field decisions: (1) straight steps stop on the VIO or the tag-anchored displacement, whichever is
larger; (2) one sidestep when the start is far off the centreline; (3) one backward step when the final zone has no
feasible candidate."""
import math,unittest
from docking.controller import Controller
from support import config,observation

def started(c=None):
    c=c or config();c['tuning']['preparation_s']=1.;x=Controller(c,-2.5,0.)
    x.step(0.,observation(0.),True)
    for i in range(1,12):x.step(i/10,observation(i/10))
    x.step(1.2,observation(1.2),True);return x

class TagRulerTests(unittest.TestCase):
    def test_step_stops_on_tag_motion_when_vio_is_frozen(self):
        x=started();x.begin_drive(2.,observation(2.),.8,False);self.assertEqual(x.state,'MOVING')
        t=2.;xw=-5.
        for k in range(40):
            t+=.1;xw+=.029;x.step(t,observation(t,world=(xw,0.,0.),local=(0.,0.,0.),stationary=False))
            if x.state!='MOVING':break
        self.assertEqual(x.state,'SETTLE');self.assertLess(xw+5.,1.0)
        parts=x.brake['progress_parts'];self.assertAlmostEqual(parts[0],0.,places=6);self.assertGreater(parts[1],.5)
    def test_vio_alone_still_stops_when_the_tag_is_lost(self):
        x=started();x.begin_drive(2.,observation(2.),.5,False)
        t=2.;xl=0.
        for k in range(40):
            t+=.1;xl+=.029
            x.step(t,observation(t,local=(xl,0.,0.),stationary=False,usable=False,pose=None,tag=dict(ok=False,detected=False,reason='no_tag')))
            if x.state!='MOVING':break
        self.assertIn(x.state,('SETTLE','RECOVER'),x.status()['reason'])

class LastResortBackwardTests(unittest.TestCase):
    def test_no_feasible_progress_backs_once_then_faults(self):
        x=started();x.state='PLAN';x.cut=-1.0;o=observation(5.,world=(-3.3,-.2,0.))   # cut -1.0: both poses stay before the alignment line
        x.step(5.,o);self.assertEqual(x.state,'PLANNING')
        x.accept_plan(dict(id=x.plan_id,plan=dict(actions=[],complete=False,reason='no_feasible_progress')),5.1,observation(5.1,world=(-3.3,-.2,0.)))
        self.assertEqual(x.state,'MOVING');self.assertEqual(x.command,'backward');self.assertAlmostEqual(x.action['target'],.5)
        self.assertIn('no_feasible_progress_backing_once',[e['event'] for e in x.events])
        x.stop(6.,'PLAN');x.step(8.,observation(8.,world=(-3.8,-.2,0.)));x.step(8.1,observation(8.1,world=(-3.8,-.2,0.)))
        self.assertEqual(x.state,'PLANNING')
        x.accept_plan(dict(id=x.plan_id,plan=dict(actions=[],complete=False,reason='no_feasible_progress')),8.2,observation(8.2,world=(-3.8,-.2,0.)))
        self.assertEqual(x.state,'FAULT')

class SidestepTests(unittest.TestCase):
    def test_far_off_centreline_start_sidesteps_once(self):
        x=started();x.state='PLAN';x.cut=-3.3
        p=(-7.,-1.,0.)                                  # 1 m right of the centreline, 3.7 m of room
        x.step(5.,observation(5.,world=p));self.assertEqual(x.state,'MOVING');self.assertEqual(x.command,'rotate_left_slow')   # face +90 deg
        self.assertAlmostEqual(x.action['target'],math.pi/2,places=6);self.assertEqual(x.action['after'],'SIDESTEP')
        self.assertEqual([k for k,_ in x.sidestep_legs],['drive','turn'])
        from docking.geometry import moved,wrap
        q1=moved(p,wrap(math.pi/2-p[2]),0,x.cfg['pivot']);y_end0=moved(q1,wrap(0.-q1[2]),0,x.cfg['pivot'])[1]
        self.assertAlmostEqual(x.sidestep_legs[0][1],min(1.5,.9*(-y_end0)),places=6)   # drive covers both pivot swings (2026-10-20)
        self.assertAlmostEqual(moved(moved(q1,0,x.sidestep_legs[0][1]/.9,x.cfg['pivot']),wrap(0.-q1[2]),0,x.cfg['pivot'])[1],0.,places=6)   # full drive would land on the centreline
        self.assertIn('sidestep',[e['event'] for e in x.events])
        # a second plan request on the same spot does not sidestep again
        x.sidestep_legs=[];x.action=None;x.state='PLAN';x.step(20.,observation(20.,world=p));self.assertEqual(x.state,'PLANNING')
    def test_no_sidestep_when_close_or_near_centreline(self):
        x=started();x.state='PLAN';x.cut=-3.3;x.step(5.,observation(5.,world=(-7.,-.3,0.)));self.assertEqual(x.state,'PLANNING')   # near the centreline: plan
        x=started();x.state='PLAN';x.cut=-3.3;x.step(5.,observation(5.,world=(-3.8,-1.,0.)));self.assertFalse(x.sidestepped)   # inside the alignment line: no sidestep (line logic)
    def test_sidestep_legs_tolerate_a_lost_tag(self):
        x=started();x.state='PLAN';x.cut=-3.3;x.step(5.,observation(5.,world=(-7.,-1.,0.)))
        t=5.;yaw=0.
        for k in range(100):   # turning with the tag out of view: must not recover/fault
            t+=.1;yaw=min(math.pi/2,yaw+math.radians(12)*.1)
            x.step(t,observation(t,world=(-7.,-1.,yaw),local=(0.,0.,yaw),stationary=False,tag=dict(ok=False,detected=False,reason='no_tag')))
            if x.state!='MOVING':break
        self.assertEqual(x.state,'SETTLE',x.status()['reason'])

class AlignmentLineTests(unittest.TestCase):
    def test_planner_goal_is_the_line_before_it(self):
        from docking.planner import plan
        from docking.geometry import moved
        c=config();cut=-3.3;line=cut-c['tuning']['final_straight_m']
        r=plan(c,(-8.,0.,0.),cut,{});q=[-8.,0.,0.]
        for a in r['actions']:q=moved(q,a['turn'],a['distance'],c['pivot'])
        self.assertLessEqual(q[0],line+.1,r)   # never planned past the alignment line
    def test_straight_leg_when_arrival_is_within_tolerance(self):
        x=started();x.state='PLAN';x.cut=-3.3
        x.step(5.,observation(5.,world=(-4.8,0.,0.)));self.assertEqual(x.state,'MOVING');self.assertEqual(x.command,'forward')
        self.assertAlmostEqual(x.action['target'],1.5,places=6);self.assertIn('line_straight_leg',[e['event'] for e in x.events])
    def test_aim_turn_when_arrival_is_off(self):
        x=started();x.state='PLAN';x.cut=-3.3
        x.step(5.,observation(5.,world=(-4.8,-.10,0.)));self.assertEqual(x.state,'MOVING');self.assertEqual(x.command,'rotate_left_fine')
        self.assertIn('line_aim_turn',[e['event'] for e in x.events]);self.assertEqual(x.line_corrections,1)
    def test_line_corrections_bounded_then_straight(self):
        x=started();x.state='PLAN';x.cut=-3.3;x.line_corrections=x.t['line_corrections_max']
        x.step(5.,observation(5.,world=(-4.8,-.10,0.)));self.assertEqual(x.command,'forward')
        self.assertIn('line_corrections_exhausted_going_straight',[e['event'] for e in x.events])

if __name__=='__main__':unittest.main()
